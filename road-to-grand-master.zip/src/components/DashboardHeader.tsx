import { Crown, Sparkles, User, Shield, Users } from "lucide-react";
import { UserRole } from "../types";

interface DashboardHeaderProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  isLichessOnline: boolean;
}

export default function DashboardHeader({
  currentRole,
  onRoleChange,
  isLichessOnline,
}: DashboardHeaderProps) {
  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-50 px-4 py-4 md:px-8 shadow-xs">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2.5 rounded-2xl shadow-md shadow-indigo-100 flex items-center justify-center">
            <Crown className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-display font-black text-xl md:text-2xl text-indigo-950 tracking-tight flex items-center gap-2">
              Road to Grand Master
              <span className="text-[10px] bg-amber-100 text-amber-800 font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border border-amber-200 flex items-center gap-1 animate-pulse">
                <Sparkles className="w-3 h-3" /> AI Powered
              </span>
            </h1>
            <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2 mt-0.5">
              <span>Monitoring Akun:</span>
              <span className="font-mono font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">VarishaChess</span>
              <span className="flex items-center gap-1.5 ml-1">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isLichessOnline ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-slate-300"
                  }`}
                />
                <span className={`text-[10px] font-bold uppercase tracking-wider ${isLichessOnline ? "text-emerald-600" : "text-slate-400"}`}>
                  {isLichessOnline ? "Lichess Online" : "Offline"}
                </span>
              </span>
            </div>
          </div>
        </div>

        {/* Role Switcher */}
        <div className="flex bg-slate-100/80 p-1.5 rounded-2xl border border-slate-200 self-start md:self-auto gap-1">
          <button
            onClick={() => onRoleChange("pemain")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer ${
              currentRole === "pemain"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200"
                : "text-slate-500 hover:text-indigo-600 hover:bg-white/50"
            }`}
          >
            <User className="w-4 h-4" />
            <span>Pemain (Varisha)</span>
          </button>
          <button
            onClick={() => onRoleChange("orangtua")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer ${
              currentRole === "orangtua"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200"
                : "text-slate-500 hover:text-indigo-600 hover:bg-white/50"
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Orang Tua</span>
          </button>
          <button
            onClick={() => onRoleChange("pelatih")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer ${
              currentRole === "pelatih"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200"
                : "text-slate-500 hover:text-indigo-600 hover:bg-white/50"
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Pelatih AI</span>
          </button>
        </div>
      </div>
    </header>
  );
}
