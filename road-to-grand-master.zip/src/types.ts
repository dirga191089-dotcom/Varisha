export interface LichessProfile {
  id: string;
  username: string;
  online: boolean;
  perfs: {
    blitz: { games: number; rating: number; rd: number; prog: number };
    bullet: { games: number; rating: number; rd: number; prog: number };
    rapid: { games: number; rating: number; rd: number; prog: number };
    puzzle: { games: number; rating: number; rd: number; prog: number };
  };
  createdAt: number;
  seenAt: number;
  playTime: { total: number; tv: number };
  count: { all: number; rated: number; win: number; loss: number; draw: number };
}

export interface LichessPlayer {
  user: { name: string; id: string };
  rating: number;
  ratingDiff?: number;
}

export interface LichessGame {
  id: string;
  rated: boolean;
  speed: string;
  perf: string;
  createdAt: number;
  players: {
    white: LichessPlayer;
    black: LichessPlayer;
  };
  winner?: "white" | "black";
  status: string;
  opening?: { name: string };
  moves: string;
}

export interface DailyTask {
  id: string;
  title: string;
  done: boolean;
  category: string;
  xp: number;
}

export interface NotificationItem {
  id: string;
  timestamp: string;
  category: "achievement" | "coach" | "system" | "parent";
  message: string;
  role: string;
}

export interface CoachNote {
  id: string;
  date: string;
  author: string;
  content: string;
}

export interface ParentSettings {
  dailyTargetMinutes: number;
  allowedLichessHoursStart: string;
  allowedLichessHoursEnd: string;
  parentRewardItem: string;
  parentRewardPointsThreshold: number;
  practiceApprovalStatus: "Approved" | "Pending" | "Review";
}

export interface CurriculumPhase {
  title: string;
  ratingRange: string;
  duration: string;
  focus: string[];
  description: string;
  syllabus: string[];
}

export interface CurriculumData {
  summary: string;
  phases: CurriculumPhase[];
  dailyStructure: {
    tacticsMinutes: number;
    playMinutes: number;
    analysisMinutes: number;
    endgameMinutes: number;
    recommendations: string[];
  };
  inspirationalQuote: string;
}

export interface GameAnalysis {
  title: string;
  openingVerdict: string;
  brilliantMove: string;
  improvement: string;
  tacticalTip: string;
  overallVerdict: string;
  score: number;
}

export interface InteractivePuzzle {
  id: string;
  title: string;
  instruction: string;
  moves: string;
  difficulty: string;
}

export interface PuzzleTheme {
  themeName: string;
  description: string;
  gamesAnalyzedSource: string;
  weaknessDetected: string;
  interactivePuzzles: InteractivePuzzle[];
  gmRiddle: string;
}

export type UserRole = "pemain" | "orangtua" | "pelatih";
