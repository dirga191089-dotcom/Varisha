import React, { useState } from "react";
import {
  Bell,
  TrendingUp,
  ShieldAlert,
  Award,
  Sparkles,
  Save,
  Clock,
  ThumbsUp,
  Heart,
  Gamepad2,
  Brain,
  Zap,
} from "lucide-react";
import {
  LichessProfile,
  NotificationItem,
  ParentSettings,
} from "../types";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

interface OrangTuaDashboardProps {
  lichessProfile: LichessProfile | null;
  notifications: NotificationItem[];
  settings: ParentSettings;
  onUpdateSettings: (newSettings: Partial<ParentSettings>) => void;
  completedXp: number;
}

// Simulated rating progress over the last 6 months for VarishaChess
const ratingHistoryData = [
  { month: "Jan", Rapid: 1420, Blitz: 1350, Puzzle: 1550 },
  { month: "Feb", Rapid: 1480, Blitz: 1410, Puzzle: 1620 },
  { month: "Mar", Rapid: 1530, Blitz: 1480, Puzzle: 1710 },
  { month: "Apr", Rapid: 1590, Blitz: 1510, Puzzle: 1780 },
  { month: "May", Rapid: 1640, Blitz: 1580, Puzzle: 1810 },
  { month: "Jun", Rapid: 1680, Blitz: 1610, Puzzle: 1850 },
  { month: "Jul", Rapid: 1720, Blitz: 1650, Puzzle: 1890 },
];

export default function OrangTuaDashboard({
  lichessProfile,
  notifications,
  settings,
  onUpdateSettings,
  completedXp,
}: OrangTuaDashboardProps) {
  const [formData, setFormData] = useState({
    dailyTargetMinutes: settings.dailyTargetMinutes,
    allowedLichessHoursStart: settings.allowedLichessHoursStart,
    allowedLichessHoursEnd: settings.allowedLichessHoursEnd,
    parentRewardItem: settings.parentRewardItem,
    parentRewardPointsThreshold: settings.parentRewardPointsThreshold,
  });
  const [saveSuccess, setSaveSuccess] = useState(false);

  const profile = lichessProfile || {
    id: "varishachess",
    username: "VarishaChess",
    online: false,
    perfs: {
      rapid: { rating: 1720, prog: 48, games: 320 },
      blitz: { rating: 1650, prog: 35, games: 412 },
      bullet: { rating: 1520, prog: -12, games: 184 },
      puzzle: { rating: 1890, prog: 80, games: 1250 },
    },
    count: { all: 916, win: 485, loss: 401 },
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const winRatio = Math.round((profile.count.win / (profile.count.all || 1)) * 100);

  return (
    <div className="space-y-8 text-slate-800">
      {/* Real-time Quick Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Rapid Rating */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-5 flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-extrabold text-slate-400 flex items-center gap-1.5 tracking-wider">
              <Brain className="w-3.5 h-3.5 text-blue-500" /> Rating Rapid
            </span>
            <p className="font-mono text-2xl font-black text-indigo-950">
              {profile.perfs.rapid.rating}
            </p>
            <p className="text-xs text-slate-500">Total: {profile.perfs.rapid.games} game</p>
          </div>
          <div className="text-right">
            <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-full border border-emerald-200 font-extrabold">
              +{profile.perfs.rapid.prog}
            </span>
          </div>
        </div>

        {/* Blitz Rating */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-5 flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-extrabold text-slate-400 flex items-center gap-1.5 tracking-wider">
              <Zap className="w-3.5 h-3.5 text-amber-500" /> Rating Blitz
            </span>
            <p className="font-mono text-2xl font-black text-indigo-950">
              {profile.perfs.blitz.rating}
            </p>
            <p className="text-xs text-slate-500">Total: {profile.perfs.blitz.games} game</p>
          </div>
          <div className="text-right">
            <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-full border border-emerald-200 font-extrabold">
              +{profile.perfs.blitz.prog}
            </span>
          </div>
        </div>

        {/* Puzzles Rating */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-5 flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-extrabold text-slate-400 flex items-center gap-1.5 tracking-wider">
              <Gamepad2 className="w-3.5 h-3.5 text-emerald-500" /> Rating Taktik
            </span>
            <p className="font-mono text-2xl font-black text-indigo-950">
              {profile.perfs.puzzle.rating}
            </p>
            <p className="text-xs text-slate-500">Total: {profile.perfs.puzzle.games} puzzle</p>
          </div>
          <div className="text-right">
            <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-full border border-emerald-200 font-extrabold">
              +{profile.perfs.puzzle.prog}
            </span>
          </div>
        </div>

        {/* Win Ratio */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-5 flex items-center justify-between shadow-xs">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-extrabold text-slate-400 flex items-center gap-1.5 tracking-wider">
              <Award className="w-3.5 h-3.5 text-rose-500" /> Rasio Kemenangan
            </span>
            <p className="font-mono text-2xl font-black text-indigo-950">{winRatio}%</p>
            <p className="text-xs text-slate-500">Total: {profile.count.all} tanding</p>
          </div>
          <div className="text-right">
            <span className="text-[10px] bg-amber-50 text-amber-700 px-2.5 py-1 rounded-full border border-amber-200 font-extrabold">
              GM Track
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Rating Trend Chart */}
        <div className="lg:col-span-8 bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="font-display font-black text-lg text-indigo-950 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-indigo-600" /> Tren Rating Varisha
              </h3>
              <p className="text-xs text-slate-400">Grafik perkembangan rating 6 bulan terakhir</p>
            </div>
            <div className="flex gap-4 text-xs font-bold">
              <span className="flex items-center gap-1 text-blue-600">
                <span className="w-2.5 h-2.5 bg-blue-500 rounded-full" /> Rapid
              </span>
              <span className="flex items-center gap-1 text-amber-600">
                <span className="w-2.5 h-2.5 bg-amber-500 rounded-full" /> Blitz
              </span>
              <span className="flex items-center gap-1 text-emerald-600">
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full" /> Taktik
              </span>
            </div>
          </div>

          <div className="h-72 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={ratingHistoryData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRapid" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorBlitz" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorPuzzle" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} domain={["dataMin - 100", "dataMax + 100"]} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#ffffff", borderColor: "#e2e8f0", borderRadius: "16px", color: "#1e293b", boxShadow: "0 4px 12px rgba(0,0,0,0.05)" }}
                  labelClassName="font-extrabold text-indigo-950"
                />
                <Area type="monotone" dataKey="Rapid" stroke="#3b82f6" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRapid)" />
                <Area type="monotone" dataKey="Blitz" stroke="#f59e0b" strokeWidth={2.5} fillOpacity={1} fill="url(#colorBlitz)" />
                <Area type="monotone" dataKey="Puzzle" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorPuzzle)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right: Parental Approval & Reward Center */}
        <div className="lg:col-span-4 bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h3 className="font-display font-black text-lg text-indigo-950 flex items-center gap-2">
              <Award className="w-5 h-5 text-indigo-600" /> Hadiah & Persetujuan
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Motivasi harian agar Varisha semangat belajar</p>
          </div>

          {/* Practice tracker indicator */}
          <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-100/80 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-500 font-semibold">Target XP Harian:</span>
              <span className="font-bold text-slate-800">{completedXp} XP dikumpulkan</span>
            </div>
            <div className="w-full bg-slate-200/80 h-2 rounded-full overflow-hidden">
              <div
                className="bg-emerald-500 h-full"
                style={{ width: `${Math.min(100, (completedXp / (settings.parentRewardPointsThreshold || 1)) * 100)}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-slate-400 font-medium">Reward: {settings.parentRewardItem}</span>
              <span className="text-emerald-600 font-bold">
                {Math.round((completedXp / (settings.parentRewardPointsThreshold || 1)) * 100)}% dari target
              </span>
            </div>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => onUpdateSettings({ practiceApprovalStatus: "Approved" })}
              className={`w-full py-3.5 px-4 rounded-2xl text-xs font-bold transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${
                settings.practiceApprovalStatus === "Approved"
                  ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                  : "bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-100"
              }`}
            >
              <ThumbsUp className="w-4 h-4" />
              {settings.practiceApprovalStatus === "Approved"
                ? "Latihan Hari Ini Disetujui! ✓"
                : "Setujui Latihan Varisha Hari Ini"}
            </button>

            <div className="text-[10px] text-slate-400 text-center flex items-center justify-center gap-1.5 mt-1 font-medium">
              <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 shrink-0" /> Memberikan apresiasi positif melipatgandakan motivasi belajar catur anak.
            </div>
          </div>
        </div>
      </div>

      {/* Parental Rules Configuration Form & Live Notification Center */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Rules configuration */}
        <div className="lg:col-span-6 bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm space-y-5">
          <h3 className="font-display font-black text-lg text-indigo-950 flex items-center gap-2 border-b border-slate-100 pb-4">
            <Clock className="w-5 h-5 text-indigo-600" /> Aturan Latihan & Waktu Bermain
          </h3>

          <form onSubmit={handleSave} className="space-y-4">
            {/* Limit hours */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs text-slate-500 block font-bold uppercase tracking-wider text-[10px]">Lichess Mulai Boleh Diakses</label>
                <input
                  type="time"
                  value={formData.allowedLichessHoursStart}
                  onChange={(e) => setFormData({ ...formData, allowedLichessHoursStart: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs text-slate-500 block font-bold uppercase tracking-wider text-[10px]">Batas Selesai Diakses</label>
                <input
                  type="time"
                  value={formData.allowedLichessHoursEnd}
                  onChange={(e) => setFormData({ ...formData, allowedLichessHoursEnd: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Target hours & XP limit */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs text-slate-500 block font-bold uppercase tracking-wider text-[10px]">Target Durasi (menit/hari)</label>
                <input
                  type="number"
                  value={formData.dailyTargetMinutes}
                  onChange={(e) => setFormData({ ...formData, dailyTargetMinutes: parseInt(e.target.value) || 60 })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs text-slate-500 block font-bold uppercase tracking-wider text-[10px]">Target XP untuk Reward</label>
                <input
                  type="number"
                  value={formData.parentRewardPointsThreshold}
                  onChange={(e) =>
                    setFormData({ ...formData, parentRewardPointsThreshold: parseInt(e.target.value) || 100 })
                  }
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Reward Name */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-500 block font-bold uppercase tracking-wider text-[10px]">Hadiah untuk Varisha (jika target tercapai)</label>
              <input
                type="text"
                value={formData.parentRewardItem}
                onChange={(e) => setFormData({ ...formData, parentRewardItem: e.target.value })}
                placeholder="misal: Makan Es Krim & Buku Catur"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="pt-3">
              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-4 rounded-xl text-xs font-bold transition-all duration-300 flex items-center justify-center gap-2 shadow-md shadow-indigo-100 cursor-pointer"
              >
                <Save className="w-4 h-4" /> Simpan Aturan & Sediakan Reward
              </button>
            </div>

            {saveSuccess && (
              <p className="text-xs text-emerald-600 font-bold text-center animate-pulse">
                Aturan dan Reward berhasil diperbarui! Notifikasi terkirim ke Varisha.
              </p>
            )}
          </form>
        </div>

        {/* Live Notification log (integrasi notifikasi) */}
        <div className="lg:col-span-6 bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-display font-black text-lg text-indigo-950 flex items-center gap-2 border-b border-slate-100 pb-4 mb-4">
              <Bell className="w-5 h-5 text-indigo-600" /> Log Aktivitas Latihan Varisha (Notifikasi Real-time)
            </h3>

            <div className="space-y-3.5 max-h-[320px] overflow-y-auto pr-1">
              {notifications.map((notif) => {
                let catStyle = "bg-amber-50 text-amber-800 border border-amber-100";
                if (notif.category === "achievement") catStyle = "bg-emerald-50 text-emerald-800 border border-emerald-150";
                if (notif.category === "parent") catStyle = "bg-rose-50 text-rose-800 border border-rose-150";
                if (notif.category === "coach") catStyle = "bg-blue-50 text-blue-800 border border-blue-150";

                return (
                  <div
                    key={notif.id}
                    className={`flex gap-3.5 items-start p-3.5 rounded-2xl border ${catStyle}`}
                  >
                    <span className="w-2 h-2 rounded-full mt-1.5 shrink-0 bg-current animate-pulse" />
                    <div className="space-y-1">
                      <p className="text-xs leading-relaxed font-bold">{notif.message}</p>
                      <span className="text-[9px] opacity-60 block font-mono">
                        {new Date(notif.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-slate-50 p-3.5 border border-slate-150 rounded-2xl text-[11px] text-slate-500 mt-4 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-indigo-500 shrink-0" />
            <span className="font-semibold">Notifikasi ini terhubung secara sinkron ke semua perangkat orang tua, pelatih, dan tablet latihan Varisha.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
