import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  LichessProfile,
  LichessGame,
  DailyTask,
  NotificationItem,
  CoachNote,
  ParentSettings,
  UserRole,
  PuzzleTheme,
} from "./types";
import DashboardHeader from "./components/DashboardHeader";
import PemainDashboard from "./components/PemainDashboard";
import OrangTuaDashboard from "./components/OrangTuaDashboard";
import PelatihDashboard from "./components/PelatihDashboard";
import { Flame, Brain, Sparkles, BookOpen, AlertCircle } from "lucide-react";

export default function App() {
  const [currentRole, setCurrentRole] = useState<UserRole>("pemain");

  // Server state synced data
  const [lichessProfile, setLichessProfile] = useState<LichessProfile | null>(null);
  const [lichessGames, setLichessGames] = useState<LichessGame[]>([]);
  const [tasks, setTasks] = useState<DailyTask[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [coachNotes, setCoachNotes] = useState<CoachNote[]>([]);
  const [parentSettings, setParentSettings] = useState<ParentSettings>({
    dailyTargetMinutes: 60,
    allowedLichessHoursStart: "15:00",
    allowedLichessHoursEnd: "20:00",
    parentRewardItem: "Es Krim & Buku Catur Baru",
    parentRewardPointsThreshold: 200,
    practiceApprovalStatus: "Pending",
  });
  const [completedXp, setCompletedXp] = useState(0);
  const [puzzleTheme, setPuzzleTheme] = useState<PuzzleTheme | null>(null);

  // Custom Gemini API Token provided by the user
  const [customApiKey, setCustomApiKey] = useState(() => localStorage.getItem("gemini_custom_key") || "");

  // loading state
  const [loading, setLoading] = useState(true);

  // Sync custom token changes to localStorage
  useEffect(() => {
    localStorage.setItem("gemini_custom_key", customApiKey);
  }, [customApiKey]);

  // Fetch Lichess and State data
  const loadState = async () => {
    try {
      // 1. Fetch Shared Server State
      const stateRes = await fetch("/api/chess/state");
      if (stateRes.ok) {
        const stateData = await stateRes.json();
        setTasks(stateData.dailyTasks || []);
        setNotifications(stateData.notifications || []);
        setCoachNotes(stateData.coachNotes || []);
        setParentSettings(stateData.parentSettings || {});
        setCompletedXp(stateData.completedXp || 0);
        setPuzzleTheme(stateData.puzzleTheme || null);
      }

      // 2. Fetch Lichess Profile
      const profileRes = await fetch("/api/chess/profile");
      if (profileRes.ok) {
        const pData = await profileRes.json();
        if (pData.data) {
          setLichessProfile(pData.data);
        }
      }

      // 3. Fetch Lichess Games
      const gamesRes = await fetch("/api/chess/games");
      if (gamesRes.ok) {
        const gData = await gamesRes.json();
        if (gData.games) {
          setLichessGames(gData.games);
        }
      }
    } catch (err) {
      console.error("Gagal menyinkronkan data dengan server catur", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadState();
    // Poll state every 10 seconds to create real-time feel
    const interval = setInterval(loadState, 10000);
    return () => clearInterval(interval);
  }, []);

  // Complete a task
  const handleToggleTask = async (taskId: string) => {
    try {
      const response = await fetch("/api/chess/complete-task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taskId }),
      });
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.state) {
          setTasks(data.state.dailyTasks);
          setNotifications(data.state.notifications);
          setCompletedXp(data.state.completedXp);
        }
      }
    } catch (err) {
      console.error("Gagal memperbarui status tugas", err);
    }
  };

  // Add custom exercise from coach
  const handleAddTask = async (task: { title: string; category: string; xp: number }) => {
    try {
      const response = await fetch("/api/chess/add-task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(task),
      });
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.state) {
          setTasks(data.state.dailyTasks);
          setNotifications(data.state.notifications);
        }
      }
    } catch (err) {
      console.error("Gagal menambahkan tugas latihan", err);
    }
  };

  // Add evaluation notes from coach
  const handleAddNote = async (note: { content: string }) => {
    try {
      const response = await fetch("/api/chess/add-note", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(note),
      });
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.state) {
          setCoachNotes(data.state.coachNotes);
          setNotifications(data.state.notifications);
        }
      }
    } catch (err) {
      console.error("Gagal menerbitkan catatan", err);
    }
  };

  // Update settings from parents
  const handleUpdateSettings = async (newSettings: Partial<ParentSettings>) => {
    try {
      const response = await fetch("/api/chess/update-settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSettings),
      });
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.state) {
          setParentSettings(data.state.parentSettings);
          setNotifications(data.state.notifications);
        }
      }
    } catch (err) {
      console.error("Gagal memperbarui aturan orang tua", err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center space-y-4">
        <div className="relative">
          <div className="w-16 h-16 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin" />
          <Flame className="w-6 h-6 text-amber-500 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 fill-amber-500 animate-pulse" />
        </div>
        <div className="text-center space-y-1.5">
          <h3 className="font-display font-bold text-lg text-indigo-950">Road to Grand Master</h3>
          <p className="text-xs text-slate-500 font-mono">Menyelaraskan koneksi dengan database Lichess & Gemini AI...</p>
        </div>
      </div>
    );
  }

  const isLichessOnline = lichessProfile ? lichessProfile.online : false;

  return (
    <div className="min-h-screen bg-[#FDFCFB] text-slate-800 selection:bg-indigo-600 selection:text-white font-sans pb-16 flex flex-col justify-between">
      <div>
        {/* Header component */}
        <DashboardHeader
          currentRole={currentRole}
          onRoleChange={setCurrentRole}
          isLichessOnline={isLichessOnline}
        />

        {/* Main Container */}
        <main className="max-w-7xl mx-auto px-4 py-8 md:px-8 space-y-8">
          {/* Active role banners */}
          <div className="bg-white border border-slate-200/80 p-4 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
            <div className="flex items-center gap-3">
              <span className="p-2.5 rounded-2xl bg-indigo-50 text-indigo-600">
                <Brain className="w-5 h-5 animate-pulse" />
              </span>
              <div>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Mode Dasbor Aktif:</p>
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-tight font-display">
                  {currentRole === "pemain"
                    ? "Pemain Catur Anak (VarishaChess)"
                    : currentRole === "orangtua"
                    ? "Orang Tua Pendamping (Parent Portal)"
                    : "Asisten Pelatih AI (AI Coach GM Portal)"}
                </h3>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-amber-50 px-3.5 py-1.5 rounded-xl border border-amber-200/60 text-[11px] font-semibold text-amber-800">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Target Hadiah Hari Ini: <strong className="text-amber-600">{parentSettings.parentRewardItem}</strong></span>
          </div>
        </div>

        {/* Dynamic Route/Tab rendering with Animation */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentRole}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
          >
            {currentRole === "pemain" && (
              <PemainDashboard
                tasks={tasks}
                onToggleTask={handleToggleTask}
                lichessProfile={lichessProfile}
                completedXp={completedXp}
                puzzleTheme={puzzleTheme}
              />
            )}

            {currentRole === "orangtua" && (
              <OrangTuaDashboard
                lichessProfile={lichessProfile}
                notifications={notifications}
                settings={parentSettings}
                onUpdateSettings={handleUpdateSettings}
                completedXp={completedXp}
              />
            )}

            {currentRole === "pelatih" && (
              <PelatihDashboard
                games={lichessGames}
                tasks={tasks}
                coachNotes={coachNotes}
                puzzleTheme={puzzleTheme}
                customApiKey={customApiKey}
                setCustomApiKey={setCustomApiKey}
                lichessProfile={lichessProfile}
                onUpdateState={(newState: any) => {
                  setTasks(newState.dailyTasks || []);
                  setNotifications(newState.notifications || []);
                  setCoachNotes(newState.coachNotes || []);
                  setPuzzleTheme(newState.puzzleTheme || null);
                  setCompletedXp(newState.completedXp || 0);
                }}
                onAddTask={handleAddTask}
                onAddNote={handleAddNote}
              />
            )}
          </motion.div>
        </AnimatePresence>
        </main>
      </div>

      {/* Real-time Ticker Footer */}
      <footer className="fixed bottom-0 left-0 right-0 bg-indigo-950 text-white h-11 flex items-center px-4 md:px-8 text-xs font-bold tracking-widest uppercase z-50 shadow-2xl overflow-hidden border-t border-indigo-900">
        <span className="mr-6 text-amber-400 shrink-0 flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" /> LIVE FEED:
        </span>
        <div className="flex gap-10 whitespace-nowrap animate-marquee">
          <span>• VarishaChess baru saja menyelesaikan Taktik Harian #10</span>
          <span className="opacity-60">• Rating Rapid Lichess terupdate: {lichessProfile?.perfs.rapid.rating || 1720}</span>
          <span className="opacity-60">• Target Es Krim & Buku Catur baru tercapai {Math.round((completedXp / (parentSettings.parentRewardPointsThreshold || 1)) * 100)}%</span>
          <span className="opacity-60">• Modul Kurikulum Baru: 'Prinsip Oposisi Kritis' diaktifkan</span>
        </div>
      </footer>
    </div>
  );
}
