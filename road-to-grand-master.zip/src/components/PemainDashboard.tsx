import { useState, useEffect } from "react";
import {
  CheckCircle2,
  Circle,
  Clock,
  Flame,
  Award,
  Sparkles,
  ChevronRight,
  BookOpen,
  Sword,
  Compass,
  Tv,
  RotateCw,
  Target,
  Brain,
  HelpCircle,
  ThumbsUp,
} from "lucide-react";
import { DailyTask, CurriculumData, LichessProfile, PuzzleTheme } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface PemainDashboardProps {
  tasks: DailyTask[];
  onToggleTask: (id: string) => void;
  lichessProfile: LichessProfile | null;
  completedXp: number;
  puzzleTheme: PuzzleTheme | null;
}

export default function PemainDashboard({
  tasks,
  onToggleTask,
  lichessProfile,
  completedXp,
  puzzleTheme,
}: PemainDashboardProps) {
  const [curriculum, setCurriculum] = useState<CurriculumData | null>(null);
  const [loadingCurriculum, setLoadingCurriculum] = useState(false);
  const [customRating, setCustomRating] = useState<number>(1720);

  // States for interactive daily puzzle trainer
  const [activePuzzleIdx, setActivePuzzleIdx] = useState<number>(0);
  const [solvedPuzzleIds, setSolvedPuzzleIds] = useState<string[]>([]);
  const [showMovesForId, setShowMovesForId] = useState<string | null>(null);
  const [riddleGuess, setRiddleGuess] = useState("");
  const [riddleResult, setRiddleResult] = useState<"correct" | "incorrect" | null>(null);

  // Load default/fetched rating
  useEffect(() => {
    if (lichessProfile) {
      setCustomRating(lichessProfile.perfs.rapid.rating);
    }
  }, [lichessProfile]);

  // Load curriculum from server
  const fetchCurriculum = async (ratingVal: number) => {
    setLoadingCurriculum(true);
    try {
      const response = await fetch("/api/chess/curriculum", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentRating: ratingVal }),
      });
      const data = await response.json();
      if (data.success && data.curriculum) {
        setCurriculum(data.curriculum);
      } else if (data.curriculum) {
        setCurriculum(data.curriculum); // fallback still has data
      }
    } catch (err) {
      console.error("Gagal memuat kurikulum", err);
    } finally {
      setLoadingCurriculum(false);
    }
  };

  useEffect(() => {
    fetchCurriculum(customRating);
  }, []);

  const totalXpPossible = tasks.reduce((acc, t) => acc + t.xp, 0);
  const progressPercent = Math.min(100, Math.round((completedXp / (totalXpPossible || 1)) * 100));

  // Determine category visual styling
  const getCategoryStyles = (category: string, isDone: boolean) => {
    const normCat = category.toLowerCase();
    if (isDone) {
      return {
        card: "bg-slate-50/70 border-l-4 border-emerald-500 opacity-75",
        badge: "bg-emerald-100 text-emerald-800 border border-emerald-200",
        iconColor: "text-emerald-500",
      };
    }

    if (normCat.includes("taktik") || normCat.includes("puzzle")) {
      return {
        card: "bg-orange-50/80 border-l-4 border-orange-400 hover:bg-orange-50",
        badge: "bg-orange-100 text-orange-800 border border-orange-200",
        iconColor: "text-orange-500",
      };
    } else if (normCat.includes("main") || normCat.includes("rapid") || normCat.includes("game")) {
      return {
        card: "bg-blue-50/80 border-l-4 border-blue-400 hover:bg-blue-50",
        badge: "bg-blue-100 text-blue-800 border border-blue-200",
        iconColor: "text-blue-500",
      };
    } else if (normCat.includes("analisis") || normCat.includes("evaluasi")) {
      return {
        card: "bg-emerald-50/80 border-l-4 border-emerald-400 hover:bg-emerald-50",
        badge: "bg-emerald-100 text-emerald-800 border border-emerald-200",
        iconColor: "text-emerald-500",
      };
    } else {
      return {
        card: "bg-indigo-50/80 border-l-4 border-indigo-400 hover:bg-indigo-50",
        badge: "bg-indigo-100 text-indigo-800 border border-indigo-200",
        iconColor: "text-indigo-500",
      };
    }
  };

  return (
    <div className="space-y-8">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-[32px] bg-indigo-600 border border-indigo-700 p-6 md:p-8 shadow-lg shadow-indigo-100">
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-64 h-64 bg-amber-400/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 border border-white/20 text-xs font-bold text-white">
              <Flame className="w-3.5 h-3.5 text-amber-300 fill-amber-300 animate-pulse" /> Streak Latihan: 7 Hari Beruntun!
            </div>
            <h2 className="font-display font-black text-3xl md:text-4xl text-white tracking-tight">
              Halo, <span className="text-amber-300">VarishaChess!</span> 👋
            </h2>
            <p className="text-indigo-100 text-sm md:text-base max-w-xl leading-relaxed">
              Setiap langkah, taktik, dan evaluasi yang kamu lakukan hari ini mendekatkan kamu ke mimpi menjadi seorang <span className="text-amber-300 font-extrabold">Grand Master</span>. Ayo melangkah!
            </p>
          </div>

          {/* Gamified Level Board */}
          <div className="bg-indigo-700/50 border border-indigo-500/40 p-5 rounded-3xl flex flex-col items-center justify-center text-center min-w-[200px] shadow-inner text-white">
            <div className="relative w-16 h-16 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-4 border-indigo-800" />
              <svg className="absolute inset-0 w-16 h-16 transform -rotate-90">
                <circle
                  cx="32"
                  cy="32"
                  r="28"
                  className="stroke-amber-400"
                  strokeWidth="4"
                  fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 28}`}
                  strokeDashoffset={`${2 * Math.PI * 28 * (1 - progressPercent / 100)}`}
                />
              </svg>
              <Award className="w-7 h-7 text-amber-300" />
            </div>
            <span className="font-display font-black text-lg text-white mt-3">Level 12</span>
            <span className="text-xs text-indigo-200 mt-0.5">National Candidate</span>
            <div className="w-full bg-indigo-900 h-2 rounded-full mt-3 overflow-hidden">
              <div
                className="bg-amber-400 h-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="font-mono text-[10px] text-amber-300 font-bold mt-1.5">
              {completedXp} / {totalXpPossible} XP Hari Ini ({progressPercent}%)
            </span>
          </div>
        </div>
      </div>

      {/* Tema Puzzle Hari Ini (Lichess Match Analysis Powered) */}
      <div className="bg-white border border-slate-200/80 rounded-[32px] p-6 md:p-8 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-[10px] font-bold text-amber-800 uppercase tracking-wider">
              <Sparkles className="w-3 h-3 text-amber-500 animate-pulse" /> Analisis Lichess Otomatis
            </div>
            <h3 className="font-display font-black text-xl text-indigo-950 flex items-center gap-2">
              <Brain className="w-6 h-6 text-indigo-600 animate-pulse" /> Tema Puzzle Hari Ini: <span className="text-indigo-600">{puzzleTheme?.themeName || "Pin (Taktik Peniti)"}</span>
            </h3>
            <p className="text-xs text-slate-400">
              Tema taktik berubah otomatis setiap hari berdasarkan analisis mendalam riwayat game Lichess Anda.
            </p>
          </div>
          <div className="shrink-0 text-right md:border-l border-slate-100 md:pl-6">
            <span className="text-[10px] font-mono font-bold bg-indigo-50 px-2.5 py-1 rounded-md text-indigo-600 border border-indigo-100 block">
              Sumber: {puzzleTheme?.gamesAnalyzedSource || "Game Lichess Terakhir"}
            </span>
            <span className="text-[10px] text-amber-600 font-bold mt-1.5 block">
              ⚠️ Kelemahan terdeteksi: {puzzleTheme?.weaknessDetected || "Melewatkan ancaman taktis perwira"}
            </span>
          </div>
        </div>

        {puzzleTheme ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left side: Tactic details & Interactive Simulated Puzzles */}
            <div className="lg:col-span-8 space-y-5">
              <div className="bg-slate-50 border border-slate-200/60 p-5 rounded-2xl">
                <h4 className="font-bold text-sm text-indigo-950 mb-1.5">Apa itu {puzzleTheme.themeName}?</h4>
                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {puzzleTheme.description}
                </p>
              </div>

              {/* Interactive Pocket Trainer Panel */}
              <div className="border border-indigo-100/80 rounded-2xl overflow-hidden shadow-2xs">
                <div className="bg-indigo-950 text-white px-5 py-3.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sword className="w-4 h-4 text-amber-300 animate-bounce" />
                    <span className="text-xs font-black uppercase tracking-wider font-display">Simulator Taktik AI Coach</span>
                  </div>
                  <div className="flex gap-1.5">
                    {puzzleTheme.interactivePuzzles.map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          setActivePuzzleIdx(idx);
                          setShowMovesForId(null);
                        }}
                        className={`w-7 h-7 text-xs font-bold rounded-lg cursor-pointer flex items-center justify-center transition-all ${
                          activePuzzleIdx === idx
                            ? "bg-amber-400 text-slate-900 font-black shadow-md"
                            : solvedPuzzleIds.includes(puzzleTheme.interactivePuzzles[idx].id)
                            ? "bg-emerald-500 text-white"
                            : "bg-indigo-900 text-indigo-200 hover:bg-indigo-800"
                        }`}
                      >
                        {idx + 1}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bg-[#FAF9F6] p-5 md:p-6 space-y-4">
                  {/* Active Puzzle Display */}
                  {puzzleTheme.interactivePuzzles[activePuzzleIdx] && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded border border-amber-200">
                          Tingkat Kesukaran: {puzzleTheme.interactivePuzzles[activePuzzleIdx].difficulty}
                        </span>
                        {solvedPuzzleIds.includes(puzzleTheme.interactivePuzzles[activePuzzleIdx].id) && (
                          <span className="text-[10px] font-bold text-emerald-600 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Selesai Dipecahkan! (+10 XP)
                          </span>
                        )}
                      </div>

                      <div className="space-y-1.5">
                        <h5 className="font-display font-black text-sm text-indigo-950">
                          {puzzleTheme.interactivePuzzles[activePuzzleIdx].title}
                        </h5>
                        <p className="text-xs text-slate-600 font-medium leading-relaxed bg-white border border-slate-200/50 p-3 rounded-xl italic">
                          "{puzzleTheme.interactivePuzzles[activePuzzleIdx].instruction}"
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 pt-2">
                        <button
                          onClick={() => {
                            const pId = puzzleTheme.interactivePuzzles[activePuzzleIdx].id;
                            setShowMovesForId(pId);
                            if (!solvedPuzzleIds.includes(pId)) {
                              setSolvedPuzzleIds([...solvedPuzzleIds, pId]);
                            }
                          }}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-100 cursor-pointer"
                        >
                          Tunjukkan Kunci & Simulasikan Langkah
                        </button>

                        <button
                          onClick={() => {
                            const pId = puzzleTheme.interactivePuzzles[activePuzzleIdx].id;
                            if (!solvedPuzzleIds.includes(pId)) {
                              setSolvedPuzzleIds([...solvedPuzzleIds, pId]);
                            }
                          }}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-100 cursor-pointer"
                        >
                          Tandai Sudah Selesai Dipecahkan
                        </button>
                      </div>

                      {showMovesForId === puzzleTheme.interactivePuzzles[activePuzzleIdx].id && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl space-y-1.5"
                        >
                          <p className="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" /> Langkah Kunci Jawaban:
                          </p>
                          <p className="text-sm font-mono font-black text-slate-800 bg-white border border-slate-100 px-3 py-1.5 rounded-lg inline-block">
                            {puzzleTheme.interactivePuzzles[activePuzzleIdx].moves}
                          </p>
                          <p className="text-[10px] text-emerald-600 font-medium pt-1">
                            Luar biasa! AI Coach GM menilai pemahaman taktis Anda meningkat pesat setelah mereview kunci ini!
                          </p>
                        </motion.div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right side: AI Coach Chess Riddle */}
            <div className="lg:col-span-4 bg-amber-50/50 border border-amber-200/50 rounded-2xl p-5 md:p-6 flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2 border-b border-amber-100 pb-3">
                  <HelpCircle className="w-5 h-5 text-amber-600" />
                  <span className="font-display font-black text-xs text-amber-900 uppercase tracking-wider">Teka-Teki Catur AI GM</span>
                </div>
                <p className="text-xs italic font-medium text-amber-950 leading-relaxed bg-white border border-amber-100 p-3.5 rounded-xl">
                  "{puzzleTheme.gmRiddle}"
                </p>
              </div>

              <div className="space-y-2.5 pt-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-amber-800 uppercase tracking-wider block">Jawaban Tebakan Anda:</label>
                  <input
                    type="text"
                    value={riddleGuess}
                    onChange={(e) => setRiddleGuess(e.target.value)}
                    placeholder="Contoh: pin, garpu, benteng..."
                    className="w-full bg-white border border-amber-200/80 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-amber-400 font-sans"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      if (!riddleGuess.trim()) return;
                      const checkWord = riddleGuess.toLowerCase();
                      const keyTheme = puzzleTheme.themeName.toLowerCase();
                      if (checkWord.includes("pin") || checkWord.includes("peniti") || checkWord.includes("fork") || checkWord.includes("garpu") || checkWord.includes("skewer") || checkWord.includes("sula") || checkWord.includes("taktik") || keyTheme.includes(checkWord) || checkWord.includes(keyTheme)) {
                        setRiddleResult("correct");
                      } else {
                        setRiddleResult("incorrect");
                      }
                    }}
                    className="bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold px-4 py-2 rounded-xl text-xs cursor-pointer transition-all w-full flex items-center justify-center gap-1 shadow-md shadow-amber-200"
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>Periksa Jawaban</span>
                  </button>
                </div>

                <AnimatePresence>
                  {riddleResult && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className={`p-3 rounded-xl border text-xs font-bold leading-relaxed ${
                        riddleResult === "correct"
                          ? "bg-emerald-50 border-emerald-200 text-emerald-800"
                          : "bg-red-50 border-red-200 text-red-800"
                      }`}
                    >
                      {riddleResult === "correct" ? (
                        <p className="flex items-start gap-1.5">
                          <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                          <span>Hebat, Varisha! Tebakanmu benar! Kamu memiliki intuisi taktis layaknya Grand Master sejati! 🎖️</span>
                        </p>
                      ) : (
                        <p>
                          Aduh, masih kurang tepat. Coba perhatikan petunjuk kata taktis di deskripsi tema catur hari ini! Kamu pasti bisa!
                        </p>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-40 flex flex-col items-center justify-center text-slate-400 font-mono text-xs space-y-2">
            <RotateCw className="w-6 h-6 animate-spin text-indigo-600" />
            <p>Menunggu sinkronisasi data taktis AI Coach GM...</p>
          </div>
        )}
      </div>

      {/* Main Grid: Checklist & Workout Menu */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Side: Daily Workout Checklist */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
              <div>
                <h3 className="font-display font-black text-lg text-indigo-950 flex items-center gap-2">
                  <Target className="w-5 h-5 text-indigo-600" /> Menu Latihan Harian
                </h3>
                <p className="text-xs text-slate-400">Selesaikan tugas di bawah ini untuk mengumpulkan XP latihan</p>
              </div>
              <span className="text-xs bg-indigo-50 px-3.5 py-1.5 rounded-full text-indigo-700 font-bold border border-indigo-100">
                {tasks.filter((t) => t.done).length} / {tasks.length} Selesai
              </span>
            </div>

            {/* Checklist items */}
            <div className="space-y-3.5">
              {tasks.map((task) => {
                const styles = getCategoryStyles(task.category, task.done);
                return (
                  <div
                    key={task.id}
                    onClick={() => onToggleTask(task.id)}
                    className={`flex items-center justify-between p-4 rounded-2xl border border-slate-100 cursor-pointer transition-all duration-300 ${styles.card}`}
                  >
                    <div className="flex items-center gap-3.5">
                      {task.done ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                      ) : (
                        <Circle className="w-5 h-5 text-slate-300 hover:text-indigo-600 shrink-0" />
                      )}
                      <div>
                        <p className={`text-sm font-bold text-slate-800 ${task.done ? "line-through text-slate-400 font-medium" : ""}`}>
                          {task.title}
                        </p>
                        <span className={`text-[9px] px-2 py-0.5 rounded-md mt-1.5 inline-block font-extrabold uppercase tracking-wide ${styles.badge}`}>
                          {task.category}
                        </span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className={`font-mono text-xs font-black ${task.done ? "text-slate-400" : "text-indigo-600"}`}>
                        +{task.xp} XP
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Side: Training Allocations & Micro-Goals */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm">
            <h3 className="font-display font-black text-lg text-indigo-950 flex items-center gap-2 border-b border-slate-100 pb-4 mb-4">
              <Clock className="w-5 h-5 text-indigo-600" /> Target Alokasi Waktu
            </h3>

            {curriculum ? (
              <div className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  {/* Taktik */}
                  <div className="bg-orange-50/55 border border-orange-100 p-4 rounded-2xl flex items-center gap-3">
                    <div className="bg-orange-100 text-orange-600 p-2.5 rounded-xl">
                      <Sword className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[9px] text-orange-500 uppercase font-black tracking-wide">Taktik</p>
                      <p className="text-base font-black text-orange-950">
                        {curriculum.dailyStructure.tacticsMinutes} <span className="text-xs text-orange-700 font-medium">menit</span>
                      </p>
                    </div>
                  </div>

                  {/* Bertanding */}
                  <div className="bg-blue-50/55 border border-blue-100 p-4 rounded-2xl flex items-center gap-3">
                    <div className="bg-blue-100 text-blue-600 p-2.5 rounded-xl">
                      <Compass className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[9px] text-blue-500 uppercase font-black tracking-wide">Bermain</p>
                      <p className="text-base font-black text-blue-950">
                        {curriculum.dailyStructure.playMinutes} <span className="text-xs text-blue-700 font-medium">menit</span>
                      </p>
                    </div>
                  </div>

                  {/* Analisis */}
                  <div className="bg-emerald-50/55 border border-emerald-100 p-4 rounded-2xl flex items-center gap-3">
                    <div className="bg-emerald-100 text-emerald-600 p-2.5 rounded-xl">
                      <Tv className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[9px] text-emerald-500 uppercase font-black tracking-wide">Analisis</p>
                      <p className="text-base font-black text-emerald-950">
                        {curriculum.dailyStructure.analysisMinutes} <span className="text-xs text-emerald-700 font-medium">menit</span>
                      </p>
                    </div>
                  </div>

                  {/* Akhir */}
                  <div className="bg-indigo-50/55 border border-indigo-100 p-4 rounded-2xl flex items-center gap-3">
                    <div className="bg-indigo-100 text-indigo-600 p-2.5 rounded-xl">
                      <BookOpen className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[9px] text-indigo-500 uppercase font-black tracking-wide">Endgame</p>
                      <p className="text-base font-black text-indigo-950">
                        {curriculum.dailyStructure.endgameMinutes} <span className="text-xs text-indigo-700 font-medium">menit</span>
                      </p>
                    </div>
                  </div>
                </div>

                <div className="border-t border-slate-100 pt-4 space-y-2.5">
                  <p className="text-xs text-indigo-900 font-black flex items-center gap-1.5 uppercase tracking-wide">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Rekomendasi Latihan AI Hari Ini:
                  </p>
                  <ul className="space-y-2">
                    {curriculum.dailyStructure.recommendations.map((rec, i) => (
                      <li key={i} className="text-xs text-slate-600 flex items-start gap-2 bg-slate-50 p-2 rounded-xl border border-slate-100/50">
                        <span className="text-indigo-600 font-black shrink-0">•</span>
                        <span className="font-medium">{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="h-40 flex items-center justify-center text-xs text-slate-400 font-mono">
                Memuat rekomendasi waktu...
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Curriculum Road to GM Timeline */}
      <div className="bg-white border border-slate-200/80 rounded-[32px] p-6 md:p-8 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <h3 className="font-display font-black text-xl text-indigo-950 flex items-center gap-2">
              <Compass className="w-6 h-6 text-indigo-600 animate-spin-slow" /> Kurikulum Pendampingan "Road To GM"
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Diproduksi khusus oleh kecerdasan buatan untuk mengawal rating VarishaChess naik sampai level Grand Master
            </p>
          </div>

          {/* Regenerate controller */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 bg-slate-50 rounded-xl px-3 py-2 border border-slate-200">
              <span className="text-xs text-slate-500 font-semibold">Rating Acuan:</span>
              <input
                type="number"
                value={customRating}
                onChange={(e) => setCustomRating(parseInt(e.target.value) || 1650)}
                className="bg-transparent text-xs text-indigo-600 font-black w-14 focus:outline-none text-center font-mono"
              />
            </div>
            <button
              onClick={() => fetchCurriculum(customRating)}
              disabled={loadingCurriculum}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all duration-300 shadow-md shadow-indigo-100 cursor-pointer"
            >
              <RotateCw className={`w-3.5 h-3.5 ${loadingCurriculum ? "animate-spin" : ""}`} />
              {loadingCurriculum ? "Menganalisis..." : "Regenerasi AI"}
            </button>
          </div>
        </div>

        {curriculum ? (
          <div className="space-y-6">
            {/* AI Summary Quote */}
            <div className="bg-indigo-50/50 border border-indigo-100 p-5 rounded-2xl">
              <p className="text-sm italic text-indigo-900 font-medium leading-relaxed">
                "{curriculum.inspirationalQuote}"
              </p>
              <div className="h-px bg-indigo-100 my-3" />
              <p className="text-xs text-slate-600 leading-relaxed">
                <span className="text-indigo-800 font-black font-display uppercase tracking-wider text-[10px] mr-1.5">Analisis GM bertenaga AI:</span>{" "}
                {curriculum.summary}
              </p>
            </div>

            {/* Stages Timeline */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
              {curriculum.phases.map((phase, idx) => {
                const isActive = idx === 0; // Simulate first phase as active for 1650 rating
                return (
                  <div
                    key={idx}
                    className={`relative rounded-2xl p-5 border transition-all duration-300 flex flex-col justify-between ${
                      isActive
                        ? "bg-indigo-50/60 border-indigo-300 shadow-sm shadow-indigo-100 scale-[1.02]"
                        : "bg-slate-50/50 border-slate-200/80 opacity-90 hover:opacity-100"
                    }`}
                  >
                    {/* Active Ribbon */}
                    {isActive && (
                      <span className="absolute top-3 right-3 bg-indigo-600 text-white text-[9px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                        Fase Aktif
                      </span>
                    )}

                    <div className="space-y-3">
                      <span className="text-[10px] font-mono font-bold bg-white px-2.5 py-1 rounded-md text-indigo-600 border border-indigo-100 shadow-2xs">
                        Rating: {phase.ratingRange}
                      </span>
                      <h4 className="font-display font-black text-sm text-indigo-950 mt-1 leading-tight">
                        {phase.title}
                      </h4>
                      <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                        {phase.description}
                      </p>

                      <div className="space-y-1.5 pt-2.5 border-t border-slate-200">
                        <p className="text-[9px] font-black uppercase tracking-wider text-slate-400">Silabus:</p>
                        <ul className="space-y-1">
                          {phase.syllabus.map((syl, i) => (
                            <li key={i} className="text-[11px] text-slate-600 font-medium flex items-start gap-1">
                              <span className="text-indigo-500 shrink-0 font-bold">›</span>
                              <span>{syl}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="border-t border-slate-200 pt-3 mt-4 flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Estimasi waktu:</span>
                      <span className="text-xs text-indigo-600 font-extrabold">{phase.duration}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="h-60 flex flex-col items-center justify-center space-y-3 text-slate-400 font-mono">
            <RotateCw className="w-8 h-8 animate-spin text-indigo-600" />
            <p className="text-sm">Merumuskan kurikulum AI ideal untuk VarishaChess...</p>
          </div>
        )}
      </div>
    </div>
  );
}
