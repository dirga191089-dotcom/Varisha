import React, { useState } from "react";
import {
  BookOpen,
  PlusCircle,
  FileText,
  HelpCircle,
  Brain,
  RotateCw,
  Award,
  Sparkles,
  ChevronRight,
  User,
  Activity,
  History,
} from "lucide-react";
import { LichessGame, DailyTask, CoachNote, GameAnalysis } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface PelatihDashboardProps {
  games: LichessGame[];
  tasks: DailyTask[];
  coachNotes: CoachNote[];
  puzzleTheme: any;
  customApiKey: string;
  setCustomApiKey: (key: string) => void;
  lichessProfile: any;
  onUpdateState: (newState: any) => void;
  onAddTask: (task: { title: string; category: string; xp: number }) => void;
  onAddNote: (note: { content: string }) => void;
}

export default function PelatihDashboard({
  games,
  tasks,
  coachNotes,
  puzzleTheme,
  customApiKey,
  setCustomApiKey,
  lichessProfile,
  onUpdateState,
  onAddTask,
  onAddNote,
}: PelatihDashboardProps) {
  // Sync state & loading
  const [syncing, setSyncing] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [showApiKey, setShowApiKey] = useState(false);

  // Game analysis state
  const [selectedGame, setSelectedGame] = useState<LichessGame | null>(null);
  const [analysis, setAnalysis] = useState<GameAnalysis | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  // New task form state
  const [taskTitle, setTaskTitle] = useState("");
  const [taskCategory, setTaskCategory] = useState("Tactics");
  const [taskXp, setTaskXp] = useState(20);
  const [taskSuccess, setTaskSuccess] = useState(false);

  // New evaluation note state
  const [noteContent, setNoteContent] = useState("");
  const [noteSuccess, setNoteSuccess] = useState(false);

  const handleLichessSyncAndRegenerate = async () => {
    setSyncing(true);
    setSyncSuccess(false);
    setSyncError(null);

    try {
      const response = await fetch("/api/chess/ai-generate-coaching", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customApiKey,
          lichessProfile,
          lichessGames: games,
        }),
      });

      const data = await response.json();
      if (data.success && data.state) {
        onUpdateState(data.state);
        setSyncSuccess(true);
      } else {
        throw new Error(data.error || "Gagal menyusun menu otomatis.");
      }
    } catch (err: any) {
      console.error("Lichess AI sync failed:", err);
      setSyncError(err.message || "Gagal terhubung dengan server catur.");
    } finally {
      setSyncing(false);
    }
  };

  const triggerGameAnalysis = async (game: LichessGame) => {
    setSelectedGame(game);
    setAnalyzing(true);
    setAnalysis(null);

    const playerColor =
      game.players.white.user.name.toLowerCase() === "varishachess" ? "white" : "black";

    try {
      const response = await fetch("/api/chess/analyze-game", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          moves: game.moves,
          opponentName: playerColor === "white" ? game.players.black.user.name : game.players.white.user.name,
          ratingOpponent: playerColor === "white" ? game.players.black.rating : game.players.white.rating,
          result: game.winner,
          playerColor,
          openingName: game.opening?.name || "Langkah Terbuka",
        }),
      });
      const data = await response.json();
      if (data.success && data.analysis) {
        setAnalysis(data.analysis);
      } else if (data.analysis) {
        setAnalysis(data.analysis); // fallback
      }
    } catch (err) {
      console.error("Gagal menganalisis game", err);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleAddTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;
    onAddTask({
      title: taskTitle,
      category: taskCategory,
      xp: taskXp,
    });
    setTaskTitle("");
    setTaskSuccess(true);
    setTimeout(() => setTaskSuccess(false), 3000);
  };

  const handleAddNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent.trim()) return;
    onAddNote({ content: noteContent });
    setNoteContent("");
    setNoteSuccess(true);
    setTimeout(() => setNoteSuccess(false), 3000);
  };

  return (
    <div className="space-y-8 text-slate-800">
      {/* AI Coach GM Automatic Control Panel */}
      <div className="bg-white border border-slate-200/80 rounded-[32px] p-6 md:p-8 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-slate-100 pb-6">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-[10px] font-bold text-indigo-800 uppercase tracking-wider">
              <Sparkles className="w-3 h-3 text-indigo-500 animate-pulse" /> Modul Pelatih Catur AI GM
            </div>
            <h2 className="font-display font-black text-2xl text-indigo-950 flex items-center gap-2.5">
              <Brain className="w-7 h-7 text-indigo-600 animate-pulse" /> Panel Sinkronisasi & Latihan Otomatis
            </h2>
            <p className="text-sm text-slate-500 max-w-3xl">
              Sistem catur pintar kami sepenuhnya digerakkan oleh kecerdasan buatan. AI Coach GM menyinkronkan data pertandingan Lichess secara otomatis, menemukan kelemahan taktis riil anak, menyusun menu tugas harian baru, serta merancang tema puzzle harian beserta teka-teki catur.
            </p>
          </div>

          <div className="shrink-0 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => setShowApiKey(!showApiKey)}
              className="px-4 py-2.5 rounded-xl text-xs font-bold border border-slate-200 hover:bg-slate-50 cursor-pointer transition-all"
            >
              {showApiKey ? "Sembunyikan Pengaturan Token" : "⚙️ Pengaturan Token Gemini"}
            </button>
            <button
              onClick={handleLichessSyncAndRegenerate}
              disabled={syncing}
              className={`px-5 py-2.5 rounded-xl text-xs font-black text-white shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                syncing
                  ? "bg-indigo-400 cursor-not-allowed shadow-none"
                  : "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100 hover:-translate-y-0.5"
              }`}
            >
              {syncing ? (
                <>
                  <RotateCw className="w-4 h-4 animate-spin" />
                  <span>Menganalisis & Menyusun Latihan...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300 animate-bounce" />
                  <span>Sinkronisasi Lichess & Buat Latihan Baru</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Custom API Key input drawer */}
        <AnimatePresence>
          {showApiKey && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden bg-slate-50 border border-slate-200/60 rounded-2xl p-4 md:p-5 space-y-3"
            >
              <h4 className="font-bold text-xs text-indigo-950 uppercase tracking-wider flex items-center gap-1.5">
                🔑 Kunci API Gemini Kustom (Token)
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Secara default, aplikasi menggunakan Cloud Key terintegrasi. Jika Anda ingin menggunakan limit kuota API kunci Anda sendiri (Gemini 3.5 Flash), masukkan token Anda di bawah ini. Kunci ini hanya akan disimpan dengan aman di peramban lokal Anda.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="password"
                  value={customApiKey}
                  onChange={(e) => setCustomApiKey(e.target.value)}
                  placeholder="Masukkan Kunci API Gemini Anda (AI_...)"
                  className="bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 flex-1"
                />
                {customApiKey && (
                  <button
                    onClick={() => {
                      setCustomApiKey("");
                      localStorage.removeItem("gemini_custom_key");
                    }}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-red-600 border border-red-200 hover:bg-red-50 cursor-pointer"
                  >
                    Hapus Token
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Sync Success & Error alerts */}
        <AnimatePresence>
          {syncSuccess && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl text-xs text-emerald-800 font-bold leading-relaxed flex items-start gap-2.5"
            >
              <Sparkles className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5 animate-pulse" />
              <div>
                <p className="font-extrabold text-sm text-emerald-900 mb-0.5">Sinkronisasi Lichess & Penyusunan Latihan Berhasil! 🎉</p>
                <p className="text-emerald-700 font-medium">
                  AI Coach GM telah menganalisis sisa riwayat catur Varisha di Lichess, mendeteksi kesalahan/pola permainan terakhirnya, memformulasikan tema puzzle "{puzzleTheme?.themeName || 'Baru'}", menyusun 4 menu latihan harian yang sangat terarah, dan menulis catatan evaluasi bertenaga AI.
                </p>
              </div>
            </motion.div>
          )}

          {syncError && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-red-50 border border-red-200 p-4 rounded-2xl text-xs text-red-800 font-bold leading-relaxed flex items-start gap-2.5"
            >
              <div className="text-red-600 text-lg">⚠️</div>
              <div>
                <p className="font-extrabold text-sm text-red-900 mb-0.5">Gagal Menyusun Kurikulum Harian</p>
                <p className="text-red-700 font-medium">{syncError}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Current Active Theme HUD */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-indigo-950 text-white rounded-2xl p-5 shadow-inner">
          <div className="space-y-1">
            <span className="text-[9px] font-bold text-indigo-300 uppercase tracking-widest block">Tema Latihan Harian</span>
            <span className="font-display font-black text-base text-amber-300 block">
              {puzzleTheme?.themeName || "Pin (Taktik Peniti)"}
            </span>
          </div>
          <div className="space-y-1 border-t md:border-t-0 md:border-l border-indigo-900/60 pt-3.5 md:pt-0 md:pl-5">
            <span className="text-[9px] font-bold text-indigo-300 uppercase tracking-widest block">Dasar Analisis Lichess</span>
            <span className="text-xs font-semibold text-slate-200 block">
              {puzzleTheme?.gamesAnalyzedSource || "Analisis Lichess Game terakhir"}
            </span>
          </div>
          <div className="space-y-1 border-t md:border-t-0 md:border-l border-indigo-900/60 pt-3.5 md:pt-0 md:pl-5">
            <span className="text-[9px] font-bold text-indigo-300 uppercase tracking-widest block">Tugas Latihan Terintegrasi</span>
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1 block">
              <span className="w-2 h-2 rounded-full bg-emerald-400" /> {tasks.length} Tugas AI Terpasang
            </span>
          </div>
        </div>
      </div>

      {/* Upper Grid: Match History & AI Match Analyzer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Interactive Lichess Match List */}
        <div className="lg:col-span-5 bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm space-y-4">
          <div>
            <h3 className="font-display font-black text-lg text-indigo-950 flex items-center gap-2">
              <History className="w-5 h-5 text-indigo-600" /> Riwayat Pertandingan Lichess
            </h3>
            <p className="text-xs text-slate-400">Pilih salah satu game Varisha untuk dianalisis otomatis dengan AI</p>
          </div>

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
            {games.length === 0 ? (
              <div className="h-40 flex items-center justify-center text-xs text-slate-400 font-medium">
                Memperoleh riwayat game dari Lichess...
              </div>
            ) : (
              games.map((game) => {
                const isWhite = game.players.white.user.name.toLowerCase() === "varishachess";
                const vRating = isWhite ? game.players.white.rating : game.players.black.rating;
                const oppName = isWhite ? game.players.black.user.name : game.players.white.user.name;
                const oppRating = isWhite ? game.players.black.rating : game.players.white.rating;
                const isWinner =
                  (game.winner === "white" && isWhite) || (game.winner === "black" && !isWhite);
                const isDraw = game.winner === undefined;

                return (
                  <div
                    key={game.id}
                    onClick={() => triggerGameAnalysis(game)}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all duration-300 ${
                      selectedGame?.id === game.id
                        ? "bg-indigo-50/60 border-indigo-400 shadow-xs shadow-indigo-100"
                        : "bg-slate-50/50 border-slate-200/80 hover:border-indigo-300 hover:bg-slate-50/80"
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[10px] uppercase font-mono font-bold tracking-wider bg-white text-indigo-600 px-2.5 py-0.5 rounded-full border border-indigo-100 shadow-2xs">
                        {game.speed} • {isWhite ? "Putih" : "Hitam"}
                      </span>
                      <span className="text-slate-400 text-[10px] font-medium">
                        {new Date(game.createdAt).toLocaleDateString([], {
                          month: "short",
                          day: "numeric",
                        })}
                      </span>
                    </div>

                    <div className="flex justify-between items-center mt-3">
                      <div className="space-y-0.5">
                        <p className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider">Lawan:</p>
                        <p className="text-sm font-black text-indigo-950 truncate max-w-[150px]">
                          {oppName}
                        </p>
                        <p className="text-[10px] font-mono text-slate-400 font-bold">Rating: {oppRating}</p>
                      </div>

                      <div className="text-right">
                        {isDraw ? (
                          <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-0.5 rounded-md border border-slate-200">
                            Remis
                          </span>
                        ) : isWinner ? (
                          <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-md border border-emerald-200/60">
                            Menang +{isWhite ? game.players.white.ratingDiff : game.players.black.ratingDiff}
                          </span>
                        ) : (
                          <span className="text-xs font-black text-rose-700 bg-rose-50 px-2.5 py-0.5 rounded-md border border-rose-200/60">
                            Kalah {isWhite ? game.players.white.ratingDiff : game.players.black.ratingDiff}
                          </span>
                        )}
                        <p className="text-[10px] text-slate-400 font-bold mt-1">Varisha: {vRating}</p>
                      </div>
                    </div>

                    <p className="text-[11px] text-indigo-600 mt-3 font-bold flex items-center gap-1">
                      <span>🛡️</span> <span className="truncate">{game.opening?.name || "Italian Game"}</span>
                    </p>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right: AI Match Analysis & Evaluation Center */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm min-h-[520px] flex flex-col justify-between">
            {selectedGame ? (
              analyzing ? (
                <div className="flex-1 flex flex-col items-center justify-center space-y-4">
                  <RotateCw className="w-12 h-12 text-indigo-600 animate-spin" />
                  <div className="text-center space-y-1.5">
                    <p className="text-sm font-black text-indigo-950">Gemini AI sedang memindai langkah...</p>
                    <p className="text-xs text-slate-400 max-w-sm font-medium">
                      Mengevaluasi akurasi pembukaan, inisiatif taktis, dan transisi akhir permainan untuk VarishaChess.
                    </p>
                  </div>
                </div>
              ) : analysis ? (
                <div className="space-y-5">
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-4 border-b border-slate-100 pb-4">
                    <div>
                      <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-full border border-indigo-150 font-black flex items-center gap-1 w-max uppercase tracking-wider">
                        <Sparkles className="w-3 h-3" /> Evaluasi AI Pelatih GM
                      </span>
                      <h4 className="font-display font-black text-xl text-indigo-950 mt-1.5">{analysis.title}</h4>
                      <p className="text-xs text-slate-400 font-semibold mt-0.5">Game vs {selectedGame.players.white.user.name.toLowerCase() === "varishachess" ? selectedGame.players.black.user.name : selectedGame.players.white.user.name}</p>
                    </div>

                    <div className="flex items-center gap-2 bg-indigo-50/60 px-4 py-2.5 rounded-2xl border border-indigo-150 self-end sm:self-auto shadow-xs">
                      <div className="text-right">
                        <p className="text-[9px] uppercase tracking-wider text-indigo-400 font-extrabold">Akurasi Game</p>
                        <p className="text-[10px] text-indigo-700 font-bold">Level Performa</p>
                      </div>
                      <span className="font-mono text-3xl font-black text-indigo-950 border-l border-indigo-200 pl-3">
                        {analysis.score}
                      </span>
                    </div>
                  </div>

                  {/* Analysis Content Grid */}
                  <div className="space-y-4 overflow-y-auto max-h-[340px] pr-1">
                    {/* Opening Verdict */}
                    <div className="bg-slate-50/80 border border-slate-200/80 p-4 rounded-2xl space-y-1.5">
                      <p className="text-xs font-black text-indigo-700 flex items-center gap-1.5 uppercase tracking-wider">
                        🛡️ Analisis Teori Pembukaan
                      </p>
                      <p className="text-xs text-slate-600 font-semibold leading-relaxed">{analysis.openingVerdict}</p>
                    </div>

                    {/* Brilliant Move */}
                    <div className="bg-emerald-50/70 border border-emerald-200/50 p-4 rounded-2xl space-y-1.5">
                      <p className="text-xs font-black text-emerald-700 flex items-center gap-1.5 uppercase tracking-wider">
                        ⭐ Langkah Brilian / Inisiatif Terbaik
                      </p>
                      <p className="text-xs text-slate-600 font-semibold leading-relaxed">{analysis.brilliantMove}</p>
                    </div>

                    {/* Room for Improvement */}
                    <div className="bg-rose-50/70 border border-rose-200/50 p-4 rounded-2xl space-y-1.5">
                      <p className="text-xs font-black text-rose-700 flex items-center gap-1.5 uppercase tracking-wider">
                        💡 Ruang Evaluasi & Koreksi
                      </p>
                      <p className="text-xs text-slate-600 font-semibold leading-relaxed">{analysis.improvement}</p>
                    </div>

                    {/* Tactical Tip */}
                    <div className="bg-blue-50/70 border border-blue-200/50 p-4 rounded-2xl space-y-1.5">
                      <p className="text-xs font-black text-blue-700 flex items-center gap-1.5 uppercase tracking-wider">
                        🎯 Tips Latihan Taktik Terarah
                      </p>
                      <p className="text-xs text-slate-600 font-semibold leading-relaxed">{analysis.tacticalTip}</p>
                    </div>

                    {/* Overall GM Verdict */}
                    <div className="bg-amber-50/70 border border-amber-200/50 p-4 rounded-2xl space-y-1.5">
                      <p className="text-xs font-black text-amber-800 flex items-center gap-1.5 uppercase tracking-wider">
                        📢 Rekomendasi Akhir Pelatih
                      </p>
                      <p className="text-xs text-slate-700 font-bold leading-relaxed italic">"{analysis.overallVerdict}"</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center space-y-3">
                  <Brain className="w-12 h-12 text-indigo-600/30" />
                  <div>
                    <p className="text-sm font-black text-indigo-950">Minta Analisis AI Gemini</p>
                    <p className="text-xs text-slate-400 max-w-xs mt-1 font-semibold leading-relaxed">
                      Klik tombol dibawah untuk mengevaluasi game yang sedang terpilih secara instan dengan kecerdasan buatan.
                    </p>
                  </div>
                  <button
                    onClick={() => triggerGameAnalysis(selectedGame!)}
                    className="mt-3 bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md shadow-indigo-100 hover:bg-indigo-700 transition cursor-pointer"
                  >
                    Mulai Analisis Sekarang
                  </button>
                </div>
              )
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4">
                <Brain className="w-14 h-14 text-indigo-600/20 animate-pulse" />
                <div className="space-y-1.5">
                  <p className="text-sm font-black text-indigo-950">Belum Ada Game Terpilih</p>
                  <p className="text-xs text-slate-400 max-w-sm font-semibold leading-relaxed">
                    Pilih salah satu baris riwayat pertandingan Lichess di panel kiri untuk memulai evaluasi taktis mendalam.
                  </p>
                </div>
              </div>
            )}

            <div className="border-t border-slate-100 pt-3.5 mt-5 text-[11px] text-slate-400 flex items-center gap-2 font-medium">
              <Sparkles className="w-4 h-4 text-indigo-500 shrink-0 animate-pulse" />
              <span>Analisis ini dibuat instan dengan mengevaluasi pergerakan PGN catur dan dicocokkan dengan basis pengetahuan teoretis master.</span>
            </div>
          </div>
        </div>
      </div>

      {/* Lower Grid: Add Exercises & Coach Notes forms */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Add Training Task Form */}
        <div className="lg:col-span-6 bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm space-y-5">
          <h3 className="font-display font-black text-lg text-indigo-950 flex items-center gap-2 border-b border-slate-100 pb-4">
            <PlusCircle className="w-5 h-5 text-indigo-600" /> Tambah Tugas Latihan Harian Anak
          </h3>

          <form onSubmit={handleAddTaskSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs text-slate-500 block font-bold uppercase tracking-wider text-[10px]">Judul Latihan / Tugas</label>
              <input
                type="text"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                placeholder="misal: Pelajari 15 Pola Mat Gajah vs Kuda"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs text-slate-500 block font-bold uppercase tracking-wider text-[10px]">Kategori Materi</label>
                <select
                  value={taskCategory}
                  onChange={(e) => setTaskCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500"
                >
                  <option value="Tactics">Tactics (Taktik)</option>
                  <option value="Opening">Opening (Pembukaan)</option>
                  <option value="Middlegame">Middlegame (Strategi Tengah)</option>
                  <option value="Endgame">Endgame (Akhir Permainan)</option>
                  <option value="Games">Practice Games</option>
                  <option value="Mental">Psychology & Focus</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-slate-500 block font-bold uppercase tracking-wider text-[10px]">Hadiah Poin XP</label>
                <input
                  type="number"
                  value={taskXp}
                  onChange={(e) => setTaskXp(parseInt(e.target.value) || 15)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-4 rounded-xl text-xs font-bold transition duration-300 flex items-center justify-center gap-2 shadow-md shadow-indigo-100 cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" /> Distribusikan Tugas Ke Varisha
              </button>
            </div>

            {taskSuccess && (
              <p className="text-xs text-emerald-600 font-bold text-center animate-pulse">
                Tugas Latihan sukses ditambahkan! Varisha dan Orang Tua akan segera melihat notifikasinya.
              </p>
            )}
          </form>
        </div>

        {/* Right: Coach Evaluative Notes Form & History */}
        <div className="lg:col-span-6 bg-white border border-slate-200/80 rounded-[32px] p-6 shadow-sm space-y-5">
          <h3 className="font-display font-black text-lg text-indigo-950 flex items-center gap-2 border-b border-slate-100 pb-4">
            <FileText className="w-5 h-5 text-indigo-600" /> Tulis Evaluasi Catatan Mingguan
          </h3>

          <form onSubmit={handleAddNoteSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs text-slate-500 block font-bold uppercase tracking-wider text-[10px]">Catatan & Masukan Evaluasi Untuk Varisha & Orang Tua</label>
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                rows={3}
                placeholder="Tulis umpan balik mengenai fokus, kelebihan taktis, atau anjuran buku catur baru..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 font-bold focus:outline-none focus:border-indigo-500 resize-none"
              />
            </div>

            <div className="flex justify-between items-center pt-1">
              <span className="text-[10px] text-slate-400 font-bold tracking-wider font-mono uppercase">Tertanda: Coach Grand Master</span>
              <button
                type="submit"
                className="bg-slate-100 text-indigo-950 hover:bg-slate-200 border border-slate-300 py-2.5 px-5 rounded-xl text-xs font-bold transition duration-300 flex items-center gap-2 cursor-pointer"
              >
                Simpan & Terbitkan Catatan
              </button>
            </div>

            {noteSuccess && (
              <p className="text-xs text-emerald-600 font-bold text-center animate-pulse">
                Catatan sukses diterbitkan untuk dipelajari keluarga Varisha.
              </p>
            )}
          </form>

          {/* Past Notes History */}
          <div className="space-y-3 pt-3 border-t border-slate-100">
            <p className="text-xs font-black text-indigo-950 uppercase tracking-wider text-[10px]">Riwayat Catatan Evaluasi</p>
            <div className="space-y-3.5 max-h-[160px] overflow-y-auto pr-1">
              {coachNotes.map((note) => (
                <div key={note.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-1.5">
                  <div className="flex justify-between items-center text-[10px]">
                    <span className="font-extrabold text-indigo-600">{note.author}</span>
                    <span className="text-slate-400 font-bold font-mono">{note.date}</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed font-semibold">{note.content}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
